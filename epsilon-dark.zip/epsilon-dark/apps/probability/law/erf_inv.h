#ifndef PROBABILITE_ERFINV_H
#define PROBABILITE_ERFINV_H

double erfInv(double y);

#endif


#include "constant.h"

constexpr int Constant::LargeNumberOfSignificantDigits;
constexpr int Constant::MediumNumberOfSignificantDigits;
constexpr int Constant::ShortNumberOfSignificantDigits;

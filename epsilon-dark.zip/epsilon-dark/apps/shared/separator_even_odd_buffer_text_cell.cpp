#include "separator_even_odd_buffer_text_cell.h"
#include "hideable_even_odd_editable_text_cell.h"
#include <escher/metric.h>

namespace Shared {

void SeparatorEvenOddBufferTextCell::drawRect(KDContext * ctx, KDRect rect) const {
  EvenOddBufferTextCell::drawRect(ctx, rect);
  // Draw the separator
  KDRect separatorRect(0, 0, Metric::TableSeparatorThickness, bounds().height());
  ctx->fillRect(separatorRect, Shared::HideableEvenOddEditableTextCell::hideColor());
}

void SeparatorEvenOddBufferTextCell::layoutSubviews() {
  KDRect boundsThis = bounds();
  m_bufferTextView.setFrame(KDRect(boundsThis.left() + Metric::TableSeparatorThickness, boundsThis.top(), boundsThis.width() - Metric::TableSeparatorThickness - k_rightMargin, boundsThis.height()));
}

}

